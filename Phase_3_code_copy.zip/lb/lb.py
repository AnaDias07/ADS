import asyncio, os, itertools, time

BACKENDS = [
    ("server1", 18861),
    ("server2", 18862),
    ("server3", 18863),
]

ALGO = os.getenv("LB_ALGO", "rr")  # "rr" or "lc"
_rr = itertools.cycle(range(len(BACKENDS)))
_inflight = [0, 0, 0]

def pick_backend():
    if ALGO == "lc":
        return min(range(len(BACKENDS)), key=lambda i: _inflight[i])
    return next(_rr)

async def pump(r, w, counter):
    try:
        while True:
            data = await r.read(65536)
            if not data:
                break
            counter[0] += len(data)
            w.write(data)
            await w.drain()
    finally:
        try: w.close()
        except: pass

async def handle_client(creader, cwriter):
    peer = cwriter.get_extra_info("peername")
    i = pick_backend()
    host, port = BACKENDS[i]
    t0 = time.time()
    c2s = [0]; s2c = [0]
    try:
        # lazy connect: wait for first byte from the client
        first = await creader.read(1)
        if not first:
            print(f"[LB] {peer} closed before sending data", flush=True)
            return

        sreader, swriter = await asyncio.open_connection(host, port)
        _inflight[i] += 1
        print(f"[LB] {peer} -> {host}:{port} (algo={ALGO}, inflight={_inflight})", flush=True)

        # forward the first byte, then pump
        swriter.write(first)
        await swriter.drain()
        c2s[0] += 1

        await asyncio.gather(
            pump(creader, swriter, c2s),
            pump(sreader, cwriter, s2c),
        )
    except Exception as e:
        print(f"[LB] {peer} error to {host}:{port}: {e}", flush=True)
        try: cwriter.close()
        except: pass
    finally:
        if 0 <= i < len(_inflight):
            _inflight[i] -= 1
        dur = (time.time() - t0) * 1000
        print(f"[LB] {peer} <- {host}:{port} done ({dur:.1f} ms) bytes c->s={c2s[0]} s->c={s2c[0]} inflight={_inflight}", flush=True)

async def main():
    port = int(os.getenv("LB_PORT", "9000"))
    srv = await asyncio.start_server(handle_client, "0.0.0.0", port)
    print(f"[LB] listening on :{port} backends={BACKENDS} algo={ALGO}", flush=True)
    async with srv:
        await srv.serve_forever()

if __name__ == "__main__":
    asyncio.run(main())
